/**
 * Author: Ahmed Abdel Moamen. 
 * Date:   September, 2015
 */



package HelloWorld;

import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;

public class Main {
    public static void main(String[] args) {
        ActorSystem system = ActorSystem.create("Hello");
        ActorRef a = system.actorOf(Props.create(HelloWorld.class), "helloWorld");
    }
}
